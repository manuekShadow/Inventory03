package com.t3b.msinventory.utils;

public class Tools {
	
}
