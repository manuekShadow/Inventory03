package com.t3b.msinventory.rest.api.utils;

public class Constants {
	
	public static String QRY_TB_ALM_NUBE = "select tclave from DBA.boa_conteos_nube_sn;";
	public static String QRY_RESULT_DB = "No existen coindicencias";
	public static final String ErrorInesperado = "Ocurrio un error inesperado, comuniquese con sistemas y proporcione el siguiente codigo: %s";
	
}
