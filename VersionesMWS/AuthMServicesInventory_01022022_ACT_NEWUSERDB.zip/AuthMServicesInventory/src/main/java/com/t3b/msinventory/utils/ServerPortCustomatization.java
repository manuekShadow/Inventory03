package com.t3b.msinventory.utils;
/*
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;*/

public class ServerPortCustomatization {
/*	implements WebServerFactoryCustomizer<ConfigurableWebServerFactory> {


	@Override
	public void customize(ConfigurableWebServerFactory factory) {
		Config.cargaConfig();
		factory.setPort(Integer.parseInt(Config.ms_port));
	}
*/
}
