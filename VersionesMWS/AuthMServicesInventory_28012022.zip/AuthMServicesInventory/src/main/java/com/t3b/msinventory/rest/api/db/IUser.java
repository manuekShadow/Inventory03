package com.t3b.msinventory.rest.api.db;

public interface IUser {

	public static String SP_FN_CONSULTAINFOUSEROAUTH = "{ call dba.INVMOV_SP_FN_CONSULTAINFOUSEROAUTH(?)}";
		
}
