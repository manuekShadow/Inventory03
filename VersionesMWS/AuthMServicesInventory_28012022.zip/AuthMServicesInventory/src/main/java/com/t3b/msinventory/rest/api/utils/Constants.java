package com.t3b.msinventory.rest.api.utils;

public class Constants {
	
	public static String QRY_TB_ALM_NUBE = "select tclave from DBA.boa_conteos_nube_sn;";
	public static String QRY_RESULT_DB = "No existen coindicencias";
	
}
